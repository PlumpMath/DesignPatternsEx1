==========================Exercise Checking Report==========================
Exercise No...........: 1
First Student Details.: Dudi Rubin 039532908 
Second Student Details: Ido Perry 
Delivery Date.........: 21/08/2016
Delivered In Delay....: No
Delay Reason..........: N\A.
Visual Studio Version.: 2013
Comments..............: N\A.
========================End Exercise Checking Report========================